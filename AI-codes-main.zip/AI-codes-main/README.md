# AI-codes
## this repository contains thecodes of AI assignments

week - 1 (8puzzle.py)
week - 3 (tsp.txt)
week - 5 (minimax and alpha beta pruning) (Naughts_Crosses.py)
week - 5 (results and codes provides in folder)
